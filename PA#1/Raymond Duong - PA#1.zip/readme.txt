URL:

http://ec2-54-187-135-48.us-west-2.compute.amazonaws.com/info344NBAstats/index.php

GitHub:

I still have not received the ability to create private repositories so I have included the folder, info344NBAstats, that contains my files.