ajax-challenge
==============

File stubs and assets for the AJAX/Parse.com challenge
